
export const CLAVES_STORAGE = {
    productos: 'pos_productos',
    clientes: 'pos_clientes',
    proveedores: 'pos_proveedores',
    ventas: 'pos_ventas',
    cuentasPorCobrar: 'pos_cxc',
    ventasCobradas: 'pos_ventas_cobradas',
    ultimoNumeroFactura: 'pos_ultimo_num_factura',
    movimientosInventario: 'pos_movimientos_inventario',
    usuarios: 'pos_usuarios',
    usuarioLogueado: 'pos_usuario_logueado',
    recepcionesMercancia: 'pos_recepciones_mercancia',
    planes: 'pos_planes'
};

export const ROLES = {
    PATRON: 'patron',
    SUPERVISOR: 'supervisor',
    INVENTARIO: 'inventario',
    CAJERO: 'cajero'
} as const;

type Role = typeof ROLES[keyof typeof ROLES];

export const PERMISOS: Record<Role, string[]> = {
    [ROLES.PATRON]: ['pos', 'inventario', 'clientes', 'proveedores', 'cxc', 'ventas-cobradas', 'informes', 'movimientos', 'planes'],
    [ROLES.SUPERVISOR]: ['pos', 'inventario', 'clientes', 'proveedores', 'informes', 'movimientos', 'planes'],
    [ROLES.INVENTARIO]: ['inventario', 'proveedores', 'movimientos'],
    [ROLES.CAJERO]: ['pos', 'clientes']
};

export const PREGUNTAS_SEGURIDAD = {
    pet: '¿Cuál es el nombre de tu primera mascota?',
    school: '¿Cuál es el nombre de tu escuela primaria?',
    city: '¿En qué ciudad naciste?',
    friend: '¿Cuál es el nombre de tu mejor amigo de la infancia?',
    movie: '¿Cuál es tu película favorita?'
};
