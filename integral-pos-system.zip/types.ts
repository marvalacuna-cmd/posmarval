
export interface Producto {
    id: string;
    nombre: string;
    barcode?: string;
    costoCompra: number;
    precioVenta: number;
    stock: number;
    proveedorId?: string;
    patronId: string;
    imagen?: string;
}

export interface Cliente {
    id: string;
    nombre: string;
    telefono?: string;
    email?: string;
    patronId: string;
}

export interface Proveedor {
    id: string;
    nombre: string;
    telefono?: string;
    email?: string;
    patronId: string;
}

export interface Usuario {
    id: string;
    nombre: string;
    nombreNegocio: string;
    email: string;
    password?: string; // base64
    claveAcceso?: string; // base64
    rol: 'patron' | 'supervisor' | 'inventario' | 'cajero';
    patronId: string;
    moneda: string;
    tasaCambio: number;
    preguntaSeguridad: string;
    respuestaSeguridad: string;
    colores?: {
        primary: string;
        sidebar: string;
        secondary: string;
        success: string;
        danger: string;
        warning: string;
    };
    ultimaActualizacionTasa?: string;
}

export interface CarritoItem extends Producto {
    cantidad: number;
}

export interface VentaProducto {
    id: string;
    nombre: string;
    cantidad: number;
    precioUnitario: number;
}

export interface Venta {
    id: string;
    numeroFactura: number;
    clienteId?: string;
    fecha: string;
    productos: VentaProducto[];
    total: number;
    estado: 'pendiente' | 'pagada' | 'anulada';
    pagos?: any[];
    patronId: string;
}

export interface Cxc {
    id: string;
    numeroFactura: number;
    clienteId: string;
    ventaId: string;
    monto: number;
    saldo: number;
    fechaCompra: string;
    abonos: any[];
    estado: 'pendiente' | 'pagada' | 'anulada';
    patronId: string;
    fechaAnulacion?: string;
}

export interface VentaCobrada {
    ventaId: string;
    numeroFactura: number;
    clienteId?: string;
    fechaCompra: string;
    fechaPago: string;
    monto: number;
    estado: 'pagada' | 'anulada';
    patronId: string;
    fechaAnulacion?: string;
}

export interface Movimiento {
    id: string;
    productoId: string;
    productoNombre: string;
    cantidad: number;
    tipo: 'compra' | 'venta' | 'recepcion' | 'devolucion' | 'ajuste';
    referencia: string;
    usuarioId: string;

    fecha: string;
    patronId: string;
}

export interface RecepcionProducto {
    id: string;
    nombre: string;
    cantidad: number;
    costoUnitario: number;
}

export interface Recepcion {
    id: string;
    proveedorId: string;
    numeroFactura: string;
    fechaRecepcion: string;
    productos: RecepcionProducto[];
    totalCosto: number;
    notas?: string;
    estado: 'recibida' | 'pendiente' | 'cancelada';
    usuarioId: string;
    patronId: string;
    fechaCreacion: string;
}

export interface PlanCycle {
    receptor: string;
    paid: boolean;
    date: string;
}

export interface Plan {
    id: string;
    patronId: string;
    name: string;
    amount: number;
    frequency: 'Mensual' | 'Quincenal' | 'Semanal';
    startDate: string;
    participants: string[];
    status: 'active' | 'planning' | 'completado';
    currentCycle: number;
    cycles: PlanCycle[];
}
