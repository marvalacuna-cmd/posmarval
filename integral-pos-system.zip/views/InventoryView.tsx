
import React, { useState, useMemo } from 'react';
import type { Producto, Proveedor } from '../types';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { CLAVES_STORAGE } from '../constants';
import RecepcionMercanciaModal from '../components/RecepcionMercanciaModal';

interface InventoryViewProps {
    negocioActualId: string;
    tasaCambio: number;
}

const InventoryView: React.FC<InventoryViewProps> = ({ negocioActualId, tasaCambio }) => {
    const [productos, setProductos] = useLocalStorage<Producto[]>(CLAVES_STORAGE.productos, []);
    const [proveedores] = useLocalStorage<Proveedor[]>(CLAVES_STORAGE.proveedores, []);
    const [searchTerm, setSearchTerm] = useState('');
    const [isRecepcionModalOpen, setRecepcionModalOpen] = useState(false);

    const productosNegocio = useMemo(() => {
        return productos.filter(p => p.patronId === negocioActualId);
    }, [productos, negocioActualId]);

    const filteredProductos = useMemo(() => {
        if (!searchTerm) return productosNegocio;
        const lowercasedFilter = searchTerm.toLowerCase();
        return productosNegocio.filter(producto =>
            producto.nombre.toLowerCase().includes(lowercasedFilter) ||
            (producto.barcode && producto.barcode.toLowerCase().includes(lowercasedFilter))
        );
    }, [productosNegocio, searchTerm]);
    
    const handleRecepcionSuccess = () => {
        // This could trigger a refetch or state update if needed
        console.log("Recepción completada");
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-gray-800">Gestión de Inventario</h2>
                <div className="flex gap-2">
                    <button className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded transition">
                        Añadir Nuevo Producto
                    </button>
                    <button 
                        onClick={() => setRecepcionModalOpen(true)}
                        className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded transition"
                    >
                        Recibir Mercancía
                    </button>
                </div>
            </div>

            <div className="mb-4">
                <input
                    type="text"
                    placeholder="Buscar por nombre o código de barras..."
                    className="w-full max-w-md p-2 border border-gray-300 rounded-lg"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            
            <div className="overflow-x-auto bg-white rounded-lg shadow">
                <table className="min-w-full leading-normal">
                    <thead>
                        <tr className="border-b-2 border-gray-200 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                            <th className="px-5 py-3">Imagen</th>
                            <th className="px-5 py-3">Nombre</th>
                            <th className="px-5 py-3">Código de Barras</th>
                            <th className="px-5 py-3">Costo Compra</th>
                            <th className="px-5 py-3">Precio Venta</th>
                            <th className="px-5 py-3">Stock</th>
                            <th className="px-5 py-3">Proveedor</th>
                            <th className="px-5 py-3">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredProductos.map(prod => {
                             const proveedor = proveedores.find(p => p.id === prod.proveedorId);
                             return (
                                <tr key={prod.id} className="border-b border-gray-200 hover:bg-gray-50">
                                    <td className="px-5 py-3 text-sm">
                                        <div className="flex-shrink-0 w-12 h-12">
                                            {prod.imagen ? (
                                                <img className="w-full h-full rounded-md object-cover" src={prod.imagen} alt={prod.nombre} />
                                            ) : (
                                                <div className="w-full h-full rounded-md bg-gray-200 flex items-center justify-center text-gray-400 text-xs">Sin Imagen</div>
                                            )}
                                        </div>
                                    </td>
                                    <td className="px-5 py-3 text-sm"><p className="text-gray-900 whitespace-no-wrap">{prod.nombre}</p></td>
                                    <td className="px-5 py-3 text-sm"><p className="text-gray-600 whitespace-no-wrap font-mono">{prod.barcode || 'N/A'}</p></td>
                                    <td className="px-5 py-3 text-sm"><p className="text-gray-900 whitespace-no-wrap">${prod.costoCompra.toFixed(2)}</p></td>
                                    <td className="px-5 py-3 text-sm"><p className="text-gray-900 whitespace-no-wrap font-bold">${prod.precioVenta.toFixed(2)}</p></td>
                                    <td className="px-5 py-3 text-sm"><p className="text-gray-900 whitespace-no-wrap">{prod.stock}</p></td>
                                    <td className="px-5 py-3 text-sm"><p className="text-gray-900 whitespace-no-wrap">{proveedor ? proveedor.nombre : 'N/A'}</p></td>
                                    <td className="px-5 py-3 text-sm">
                                        <div className="flex gap-2">
                                            <button className="text-yellow-600 hover:text-yellow-900">Editar</button>
                                            <button className="text-red-600 hover:text-red-900">Eliminar</button>
                                        </div>
                                    </td>
                                </tr>
                             );
                        })}
                    </tbody>
                </table>
                 {filteredProductos.length === 0 && <p className="text-center py-4 text-gray-500">No se encontraron productos.</p>}
            </div>
            
            <RecepcionMercanciaModal
                isOpen={isRecepcionModalOpen}
                onClose={() => setRecepcionModalOpen(false)}
                onSuccess={handleRecepcionSuccess}
                negocioActualId={negocioActualId}
                tasaCambio={tasaCambio}
            />
        </div>
    );
};

export default InventoryView;
