
import React from 'react';

const PosView: React.FC = () => {
    return (
        <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-800 border-b-2 border-blue-500 pb-2 mb-4">Punto de Venta</h2>
            <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4" role="alert">
                <p className="font-bold">En construcción</p>
                <p>La vista del Punto de Venta se está implementando.</p>
            </div>
        </div>
    );
};

export default PosView;
