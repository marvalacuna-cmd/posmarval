
import React, { useState, useEffect, useMemo } from 'react';
import Modal from './Modal';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { CLAVES_STORAGE } from '../constants';
import type { Proveedor, Producto, Movimiento, Recepcion, Usuario } from '../types';

interface RecepcionMercanciaModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void;
    negocioActualId: string;
    tasaCambio: number;
}

interface ProductoEnRecepcion {
    id: string;
    nombre: string;
    stockActual: number;
    seleccionado: boolean;
    cantidad: number;
    costo: number;
    factor: number;
    pvp: number;
}


const RecepcionMercanciaModal: React.FC<RecepcionMercanciaModalProps> = ({ isOpen, onClose, onSuccess, negocioActualId, tasaCambio }) => {
    const [proveedores] = useLocalStorage<Proveedor[]>(CLAVES_STORAGE.proveedores, []);
    const [productos, setProductos] = useLocalStorage<Producto[]>(CLAVES_STORAGE.productos, []);
    const [movimientos, setMovimientos] = useLocalStorage<Movimiento[]>(CLAVES_STORAGE.movimientosInventario, []);
    const [recepciones, setRecepciones] = useLocalStorage<Recepcion[]>(CLAVES_STORAGE.recepcionesMercancia, []);
    const [usuarioLogueado] = useLocalStorage<Usuario | null>(CLAVES_STORAGE.usuarioLogueado, null);

    const [selectedProveedor, setSelectedProveedor] = useState<string>('');
    const [numeroFactura, setNumeroFactura] = useState('');
    const [productosParaRecibir, setProductosParaRecibir] = useState<ProductoEnRecepcion[]>([]);

    const proveedoresNegocio = useMemo(() => {
        return proveedores.filter(p => p.patronId === negocioActualId);
    }, [proveedores, negocioActualId]);

    useEffect(() => {
        if (selectedProveedor) {
            const productosDelProveedor = productos
                .filter(p => p.proveedorId === selectedProveedor && p.patronId === negocioActualId)
                .map(p => ({
                    id: p.id,
                    nombre: p.nombre,
                    stockActual: p.stock,
                    seleccionado: false,
                    cantidad: 1,
                    costo: p.costoCompra,
                    factor: 1.3,
                    pvp: p.precioVenta
                }));
            setProductosParaRecibir(productosDelProveedor);
        } else {
            setProductosParaRecibir([]);
        }
    }, [selectedProveedor, productos, negocioActualId]);

    const handleProductChange = (id: string, field: keyof ProductoEnRecepcion, value: string | number | boolean) => {
        setProductosParaRecibir(prev =>
            prev.map(p => {
                if (p.id === id) {
                    const updatedProduct = { ...p, [field]: value };

                    // Recalculate PVP if cost or factor changes
                    if (field === 'costo' || field === 'factor') {
                         const newCost = field === 'costo' ? Number(value) : updatedProduct.costo;
                         const newFactor = field === 'factor' ? Number(value) : updatedProduct.factor;
                         if(!isNaN(newCost) && !isNaN(newFactor) && newFactor > 0) {
                            updatedProduct.pvp = parseFloat((newCost * newFactor).toFixed(2));
                         }
                    }
                    
                    return updatedProduct;
                }
                return p;
            })
        );
    };

    const totalCosto = useMemo(() => {
        return productosParaRecibir.reduce((total, p) => {
            if (p.seleccionado && p.cantidad > 0 && p.costo >= 0) {
                return total + (p.cantidad * p.costo);
            }
            return total;
        }, 0);
    }, [productosParaRecibir]);

    const handleSubmit = () => {
        if (!selectedProveedor || !numeroFactura) {
            alert('Por favor, seleccione un proveedor e ingrese un número de factura.');
            return;
        }

        const productosSeleccionados = productosParaRecibir.filter(p => p.seleccionado && p.cantidad > 0);
        if (productosSeleccionados.length === 0) {
            alert('Debe seleccionar y especificar la cantidad de al menos un producto.');
            return;
        }

        const newRecepcion: Recepcion = {
            id: Date.now().toString(),
            proveedorId: selectedProveedor,
            numeroFactura,
            fechaRecepcion: new Date().toISOString(),
            productos: productosSeleccionados.map(p => ({
                id: p.id,
                nombre: p.nombre,
                cantidad: p.cantidad,
                costoUnitario: p.costo
            })),
            totalCosto,
            estado: 'recibida',
            usuarioId: usuarioLogueado?.id || 'system',
            patronId: negocioActualId,
            fechaCreacion: new Date().toISOString()
        };
        
        setRecepciones([...recepciones, newRecepcion]);

        const updatedProductos = [...productos];
        const newMovimientos = [...movimientos];

        productosSeleccionados.forEach(item => {
            const productIndex = updatedProductos.findIndex(p => p.id === item.id);
            if (productIndex !== -1) {
                updatedProductos[productIndex].stock += item.cantidad;
                updatedProductos[productIndex].costoCompra = item.costo;
                updatedProductos[productIndex].precioVenta = item.pvp;

                newMovimientos.push({
                    id: Date.now().toString() + item.id,
                    productoId: item.id,
                    productoNombre: item.nombre,
                    cantidad: item.cantidad,
                    tipo: 'recepcion',
                    referencia: `Recepción Factura #${numeroFactura}`,
                    usuarioId: usuarioLogueado?.id || 'system',
                    fecha: new Date().toISOString(),
                    patronId: negocioActualId
                });
            }
        });

        setProductos(updatedProductos);
        setMovimientos(newMovimientos);

        onSuccess();
        onClose();
    };
    
    const resetForm = () => {
        setSelectedProveedor('');
        setNumeroFactura('');
        setProductosParaRecibir([]);
    }

    return (
        <Modal
            isOpen={isOpen}
            onClose={() => {
                resetForm();
                onClose();
            }}
            title="Recepción de Mercancía"
            size="xl"
            footer={
                 <div className="flex gap-2">
                    <button onClick={() => { resetForm(); onClose(); }} className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded">Cancelar</button>
                    <button onClick={handleSubmit} className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">Recibir Mercancía</button>
                 </div>
            }
        >
            <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="recepcion-proveedor" className="block text-sm font-medium text-gray-700">Proveedor</label>
                        <select
                            id="recepcion-proveedor"
                            value={selectedProveedor}
                            onChange={(e) => setSelectedProveedor(e.target.value)}
                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                        >
                            <option value="">Seleccionar Proveedor</option>
                            {proveedoresNegocio.map(p => <option key={p.id} value={p.id}>{p.nombre}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="recepcion-numero-factura" className="block text-sm font-medium text-gray-700">Número de Factura</label>
                        <input
                            type="text"
                            id="recepcion-numero-factura"
                            value={numeroFactura}
                            onChange={(e) => setNumeroFactura(e.target.value)}
                            className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        />
                    </div>
                </div>

                <div className="mt-4 border-t pt-4">
                    <h4 className="text-md font-semibold text-gray-800 mb-2">Productos a Recibir</h4>
                    <div className="max-h-96 overflow-y-auto space-y-3 pr-2">
                        {productosParaRecibir.length > 0 ? productosParaRecibir.map(p => (
                            <div key={p.id} className="p-3 border rounded-md bg-gray-50 space-y-2">
                                <div className="flex items-center gap-3">
                                    <input
                                        type="checkbox"
                                        checked={p.seleccionado}
                                        onChange={(e) => handleProductChange(p.id, 'seleccionado', e.target.checked)}
                                        className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                    />
                                    <label className="font-medium text-gray-900 flex-grow">{p.nombre}</label>
                                    <span className="text-sm text-gray-500">Stock actual: {p.stockActual}</span>
                                </div>
                                {p.seleccionado && (
                                     <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pl-8">
                                        <div>
                                            <label className="text-xs text-gray-600 block">Cantidad</label>
                                            <input type="number" min="1" value={p.cantidad} onChange={(e) => handleProductChange(p.id, 'cantidad', parseInt(e.target.value) || 0)} className="w-full text-sm p-1 border rounded-md" />
                                        </div>
                                        <div>
                                            <label className="text-xs text-gray-600 block">Nuevo Costo ($)</label>
                                            <input type="number" step="0.01" min="0" value={p.costo} onChange={(e) => handleProductChange(p.id, 'costo', parseFloat(e.target.value) || 0)} className="w-full text-sm p-1 border rounded-md" />
                                        </div>
                                        <div>
                                            <label className="text-xs text-gray-600 block">Factor Venta</label>
                                            <input type="number" step="0.01" min="1" value={p.factor} onChange={(e) => handleProductChange(p.id, 'factor', parseFloat(e.target.value) || 0)} className="w-full text-sm p-1 border rounded-md" />
                                        </div>
                                        <div>
                                            <label className="text-xs text-gray-600 block">PVP Venta ($)</label>
                                            <input type="number" step="0.01" min="0" value={p.pvp} onChange={(e) => handleProductChange(p.id, 'pvp', parseFloat(e.target.value) || 0)} className="w-full text-sm p-1 border rounded-md bg-blue-50 font-bold" />
                                        </div>
                                     </div>
                                )}
                            </div>
                        )) : <p className="text-center text-gray-500 py-4">Seleccione un proveedor para ver sus productos.</p>}
                    </div>
                </div>
                 <div className="text-right font-bold text-lg mt-4 p-4 bg-gray-100 rounded-md">
                    Total Factura:
                    <span className="ml-2 text-blue-600">${totalCosto.toFixed(2)}</span>
                    <span className="ml-2 text-gray-500 text-sm">/ Bs. {(totalCosto * tasaCambio).toFixed(2)}</span>
                 </div>
            </div>
        </Modal>
    );
};

export default RecepcionMercanciaModal;
