
import React, { useState, useEffect } from 'react';
import { useLocalStorage } from './hooks/useLocalStorage';
import { ROLES, PERMISOS, CLAVES_STORAGE } from './constants';
import type { Usuario, Producto, Cliente, Proveedor, Venta, Cxc, VentaCobrada, Movimiento, Recepcion, Plan } from './types';

// Import Views
import PosView from './views/PosView';
import InventoryView from './views/InventoryView';

// Placeholder for other views to be implemented
const PlaceholderView: React.FC<{ title: string }> = ({ title }) => (
    <div className="p-6">
        <h2 className="text-2xl font-bold text-gray-800 border-b-2 border-blue-500 pb-2 mb-4">{title}</h2>
        <p>This view is under construction.</p>
    </div>
);


const App: React.FC = () => {
    // This is a simplified example focusing on POS and Inventory
    // A full implementation would require all state items from the original script
    const [usuarios, setUsuarios] = useLocalStorage<Usuario[]>(CLAVES_STORAGE.usuarios, []);
    const [productos, setProductos] = useLocalStorage<Producto[]>(CLAVES_STORAGE.productos, []);
    const [usuarioLogueado, setUsuarioLogueado] = useLocalStorage<Usuario | null>(CLAVES_STORAGE.usuarioLogueado, null);
    
    const [activeView, setActiveView] = useState('pos');

    const handleLogin = (user: Usuario) => {
        setUsuarioLogueado(user);
    };

    const handleLogout = () => {
        setUsuarioLogueado(null);
    };
    
    // In a real app, these would be separate components
    const LoginScreen = () => (
        <div className="min-h-screen flex items-center justify-center bg-gray-100">
            <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-sm">
                <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Login</h2>
                <button 
                    onClick={() => handleLogin(usuarios.find(u => u.rol === ROLES.PATRON) || usuarios[0])}
                    className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition duration-200"
                    disabled={usuarios.length === 0}
                >
                    Login as Patron (Demo)
                </button>
                {usuarios.length === 0 && <p className="text-center text-red-500 mt-4">No users found. Please register.</p>}
                 <div className="text-center mt-4">
                    <button onClick={() => {
                         const newUser: Usuario = {
                            id: 'patron1',
                            nombre: 'Admin User',
                            nombreNegocio: 'My Awesome Store',
                            email: 'admin@example.com',
                            password: btoa('password'), // base64 encoded
                            rol: ROLES.PATRON,
                            patronId: 'patron1',
                            moneda: '$',
                            tasaCambio: 36.5,
                            preguntaSeguridad: 'pet',
                            respuestaSeguridad: 'fido'
                         };
                         setUsuarios([newUser]);
                         alert('Demo user created. Please click login.');
                    }} className="text-blue-500 hover:underline">Register Demo User</button>
                </div>
            </div>
        </div>
    );

    if (!usuarioLogueado) {
        return <LoginScreen />;
    }
    
    const negocioActualId = usuarioLogueado.rol === ROLES.PATRON ? usuarioLogueado.id : usuarioLogueado.patronId;
    const permisosUsuario = PERMISOS[usuarioLogueado.rol] || [];
    const tasaCambio = usuarioLogueado.tasaCambio || 36.5;

    const navButtons = [
        { id: 'pos', text: 'Punto de Venta', permiso: 'pos' },
        { id: 'inventario', text: 'Inventario', permiso: 'inventario' },
        { id: 'clientes', text: 'Clientes', permiso: 'clientes' },
        { id: 'proveedores', text: 'Proveedores', permiso: 'proveedores' },
        { id: 'movimientos', text: 'Movimientos', permiso: 'movimientos' },
        { id: 'cxc', text: 'Cuentas por Cobrar', permiso: 'cxc' },
        { id: 'ventas-cobradas', text: 'Ventas Cobradas', permiso: 'ventas-cobradas' },
        { id: 'informes', text: 'Informes', permiso: 'informes' },
        { id: 'planes', text: 'Planes de Ahorro', permiso: 'planes' }
    ];

    const renderActiveView = () => {
        switch (activeView) {
            case 'pos':
                return <PosView />;
            case 'inventario':
                return <InventoryView negocioActualId={negocioActualId} tasaCambio={tasaCambio}/>;
            // Other cases would render their respective components
            default:
                const button = navButtons.find(b => b.id === activeView);
                return <PlaceholderView title={button ? button.text : 'Vista Desconocida'} />;
        }
    };

    return (
        <div className="h-screen grid grid-rows-[auto_1fr] grid-cols-[auto_1fr]">
            <header className="bg-slate-800 text-white p-4 flex justify-between items-center col-span-2 shadow-md">
                 <h1 className="text-xl font-bold">POS Marval</h1>
                 <div className="text-center">
                     <div className="font-semibold">{usuarioLogueado.nombreNegocio}</div>
                 </div>
                 <div className="flex items-center gap-4">
                     <span>Bienvenido, <strong>{usuarioLogueado.nombre}</strong> ({usuarioLogueado.rol})</span>
                     <button onClick={handleLogout} className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded transition">
                         Cerrar Sesión
                     </button>
                 </div>
            </header>
            <nav className="bg-slate-800 flex flex-col p-2 row-start-2 overflow-y-auto">
                {navButtons.map(btn => (
                    permisosUsuario.includes(btn.permiso) && (
                        <button
                            key={btn.id}
                            onClick={() => setActiveView(btn.id)}
                            className={`w-full text-left p-3 my-1 rounded transition ${activeView === btn.id ? 'bg-blue-500 text-white' : 'text-gray-300 hover:bg-slate-700 hover:text-white'}`}
                        >
                            {btn.text}
                        </button>
                    )
                ))}
            </nav>
            <main className="row-start-2 col-start-2 overflow-y-auto bg-gray-50">
                {renderActiveView()}
            </main>
        </div>
    );
};

export default App;
